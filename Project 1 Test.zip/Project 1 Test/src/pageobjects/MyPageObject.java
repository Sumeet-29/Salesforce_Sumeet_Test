package pageobjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.Color;
import org.openqa.selenium.support.FindBy;

import com.provar.core.testapi.annotations.*;

@Page( title="My Page Object"                                
     , summary=""
     , relativeUrl=""
     , connection="Admin_Connect"
     )             
public class MyPageObject {

	WebDriver driver;

	@ButtonType()
	@FindBy(xpath = "//div[contains(@class,'active') and contains(@class,'oneContent')]//button[normalize-space(.)='Next']")
	public WebElement next;
	@TextType()
	@FindBy(xpath = "//div[contains(@class,'active') and contains(@class,'oneContent')]//input[@id='input-154']")
	public WebElement lastName;
	@TextType()
	@FindBy(xpath = "//div[contains(@class,'active') and contains(@class,'oneContent')]//input[@id='input-157']")
	public WebElement companyName;
	
	public String checkcolor()
	{
	//obtain color in rgba
	//WebElement rgba= driver.findElement(By.xpath("//div[contains(@class,'active') and contains(@class,'oneContent')]//a[normalize-space(.)='stage completeNegotiation/Review']"));
	//change color from rgba to hex
	String hex= Color.fromString(PathAssistantStep_Negotiation_Review.getCssValue("background-color")).asHex();
	System.out.println("rgba Color is :" + PathAssistantStep_Negotiation_Review.getCssValue("background-color"));
    //System.out.println("Hex code for color:" + hex);
	return hex;
	}

	@LinkType()
	@FindBy(xpath = "//div[contains(@class,'active') and contains(@class,'oneContent')]//a[normalize-space(.)='stage completeNegotiation/Review']")
	public WebElement PathAssistantStep_Negotiation_Review;
			
}
